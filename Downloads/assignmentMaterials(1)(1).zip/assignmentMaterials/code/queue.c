#include "queue.h"

struct Queue initQueue()
{
}

void enqueue(struct Queue *qPtr, struct Data d)
{
}

struct Data dequeue(struct Queue *qPtr)
{
}
void freeQueue(struct Queue *qPtr)
{
}
