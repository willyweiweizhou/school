#include "lab3.h"

struct vInterface initVInterface(int (*sS)(int), int (*sG)(int), int (*sP)(int))
{
}
