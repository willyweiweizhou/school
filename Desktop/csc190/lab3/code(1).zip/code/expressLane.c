#include "lab3.h"

struct ExpressLaneRec * initExpressLane(float enterTime, float exitTime)
{

}

struct ExpressLaneRec * addCarRec(struct Car * c, float enterTime, float exitTime, struct ExpressLaneRec * eL)
{

}

void printRecords(struct ExpressLaneRec * eLCurr)
{

}

void cleanUpRec(struct ExpressLaneRec * eL)
{

}

