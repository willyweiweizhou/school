#include "assignment3.h"

double calcAverageWaitingTime(struct Simulation * S)
{
}

struct Simulation initSimulation(double arrivalRate, double serviceTime, double simTime)
{
}

double runSimulation(double arrivalRate, double serviceTime, double simTime)
{
}
