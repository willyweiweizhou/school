#include "lab7.h"

struct Node * insertBST(struct Node * r, struct Data d){
}

void printInOrder(struct Node * r){
}

void deleteTree(struct Node * r){
}

void printBSTs(struct Node * r1, struct Node * r2){
}