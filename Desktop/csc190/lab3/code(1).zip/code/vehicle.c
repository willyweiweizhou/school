#include "lab3.h"

struct Vehicle * initVehicle(int wheels, char * model, struct vInterface vInt)
{

}

void cleanUpVehicle(struct Vehicle * v)
{

}

