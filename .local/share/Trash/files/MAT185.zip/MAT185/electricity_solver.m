function [sol] = electricity_solver(R1, R2, R3, R4, Vo, s, eps)
    R1 = R1+s*eps(1);
    R2 = R2+s*eps(2);
    R3 = R3+s*eps(3);
    R4 = R4+s*eps(4);
    Vo = Vo+s*eps(5);
    A = [R1+R2, -R3, 0; 0, R3, R4; 1,1,-1;];
    b = [0;-Vo;0];
    [sol] = A\b;
end

    